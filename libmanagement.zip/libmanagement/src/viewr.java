import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class viewr extends javax.swing.JInternalFrame implements globals{

    public viewr() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Records");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Serial no", "Name", "Roll no/Id", "Book", "Serial no", "doI", "doS"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButton1.setText("View All");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Student Records");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Teacher Records");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Print");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton3)
                    .addComponent(jButton2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 468, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton4)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(21, 21, 21))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try
{
Connection myconnection;
myconnection=DriverManager.getConnection(PATH+PLACE,USERNAME,PASSWORD);
try
{

String q="select * from student";
PreparedStatement mystatement=myconnection.prepareStatement(q);

ResultSet myresult=mystatement.executeQuery();

DefaultTableModel mymodel=(DefaultTableModel) jTable1.getModel();
mymodel.setRowCount(0);
if(myresult.next())
{
    int x=1;
do
{
String name,rollno,book,serialno,doI,doS;
name=myresult.getString("name");
rollno=myresult.getString("rollno");
book=myresult.getString("book");
serialno=myresult.getString("serialno");
doI=myresult.getString("dateofissue");
doS=myresult.getString("dateofsubmit");
mymodel.addRow(new Object[]{x++,name,rollno,book,serialno,doI,doS});


}
while(myresult.next());
}
else
{
JOptionPane.showMessageDialog(rootPane, "No Student Record");
}

}
catch(Exception e)
{
JOptionPane.showMessageDialog(rootPane, "Error in Query due to " + e.getMessage());
}
finally
{
myconnection.close();
}

}
catch(Exception e)
{
JOptionPane.showMessageDialog(rootPane, "Error in Connection due to " + e.getMessage());
}
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try
{
Connection myconnection;
myconnection=DriverManager.getConnection(PATH+PLACE,USERNAME,PASSWORD);
try
{

String q="select * from teacher";
PreparedStatement mystatement=myconnection.prepareStatement(q);

ResultSet myresult=mystatement.executeQuery();

DefaultTableModel mymodel=(DefaultTableModel) jTable1.getModel();
mymodel.setRowCount(0);
if(myresult.next())
{
    int x=1;
do
{
String name,rollno,book,serialno,doI,doS;
name=myresult.getString("name");
rollno=myresult.getString("id");
book=myresult.getString("book");
serialno=myresult.getString("serialno");
doI=myresult.getString("dateofissue");
doS=myresult.getString("dateofsubmit");
mymodel.addRow(new Object[]{x++,name,rollno,book,serialno,doI,doS});


}
while(myresult.next());
}
else
{
JOptionPane.showMessageDialog(rootPane, "No Teacher Record");
}





}
catch(Exception e)
{
JOptionPane.showMessageDialog(rootPane, "Error in Query due to " + e.getMessage());
}
finally
{
myconnection.close();
}

}
catch(Exception e)
{
JOptionPane.showMessageDialog(rootPane, "Error in Connection due to " + e.getMessage());
}
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       try
{
Connection myconnection;
myconnection=DriverManager.getConnection(PATH+PLACE,USERNAME,PASSWORD);
try
{

String q="select * from teacher";
PreparedStatement mystatement=myconnection.prepareStatement(q);

ResultSet myresult=mystatement.executeQuery();

DefaultTableModel mymodel=(DefaultTableModel) jTable1.getModel();
mymodel.setRowCount(0);
if(myresult.next())
{
    int x=1;
do
{
String name,rollno,book,serialno,doI,doS;
name=myresult.getString("name");
rollno=myresult.getString("id");
book=myresult.getString("book");
serialno=myresult.getString("serialno");
doI=myresult.getString("dateofissue");
doS=myresult.getString("dateofsubmit");
mymodel.addRow(new Object[]{x++,name,rollno,book,serialno,doI,doS});


}
while(myresult.next());
}
else
{
JOptionPane.showMessageDialog(rootPane, "No Teacher Record");
}
}
catch(Exception e)
{
JOptionPane.showMessageDialog(rootPane, "Error in Query due to " + e.getMessage());
}

try
{

String q1="select * from student";
PreparedStatement mystatement1=myconnection.prepareStatement(q1);

ResultSet myresult1=mystatement1.executeQuery();

DefaultTableModel mymodel1=(DefaultTableModel) jTable1.getModel();

if(myresult1.next())
{
    int x=1;
do
{
String name,rollno,book,serialno,doI,doS;
name=myresult1.getString("name");
rollno=myresult1.getString("rollno");
book=myresult1.getString("book");
serialno=myresult1.getString("serialno");
doI=myresult1.getString("dateofissue");
doS=myresult1.getString("dateofsubmit");
mymodel1.addRow(new Object[]{x++,name,rollno,book,serialno,doI,doS});


}
while(myresult1.next());
}
else
{
JOptionPane.showMessageDialog(rootPane, "No Student Record");
}





}
catch(Exception e)
{
JOptionPane.showMessageDialog(rootPane, "Error in Query due to " + e.getMessage());
}
finally
{
myconnection.close();
}

}
catch(Exception e)
{
JOptionPane.showMessageDialog(rootPane, "Error in Connection due to " + e.getMessage());
}
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
try {
              MessageFormat headerFormat = new MessageFormat("Page {0}");
              MessageFormat footerFormat = new MessageFormat("- {0} -");
              jTable1.print(JTable.PrintMode.FIT_WIDTH, headerFormat, footerFormat);
            
         
            } 
    catch (PrinterException pe) 
    {
              System.err.println("Error printing: " + pe.getMessage());
        }
//       PrinterJob job = PrinterJob.getPrinterJob();
//job.setPrintable(this);
//PageFormat myformat=job.defaultPage();
//myformat.setOrientation(PageFormat.LANDSCAPE);
//
//PageFormat postformat = job.pageDialog(myformat);
//if (myformat != postformat) {
//boolean ok = job.printDialog();
//if (ok) 
//{
//try {
//
//job.print();
//
//} catch (PrinterException ex) {
//JOptionPane.showMessageDialog(rootPane, "Error in printing due to  " + ex.getMessage());
//}
//}
//}
    }//GEN-LAST:event_jButton4ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

//    @Override
//    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
//        if (pageIndex > 0) { /* We have only one page, and 'page' is zero-based */
//return NO_SUCH_PAGE;
//}
//
//// get the bounds of the component
//Dimension dim = this.getSize();
//double cHeight = dim.getHeight();
//double cWidth = dim.getWidth();
//
//// get the bounds of the printable area
//double pHeight = pageFormat.getImageableHeight();
//double pWidth = pageFormat.getImageableWidth();
//
//double pXStart = pageFormat.getImageableX();
//double pYStart = pageFormat.getImageableY();
//
//double xRatio = pWidth / cWidth;
//double yRatio = pHeight / cHeight;
//
//
//Graphics2D g2 = (Graphics2D) graphics;
//g2.translate(pXStart, pYStart);
//g2.scale(xRatio, yRatio);
//this.paint(g2);
//
//return Printable.PAGE_EXISTS;
//    }
}
