
public interface globals 
{
    String USERNAME="root";
String PASSWORD="";
String PATH="jdbc:mysql://localhost/";
String PLACE="library";


    
}
