

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;




public class Libmanagement implements globals{

  
    public static void main(String[] args) 
    {
         try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(parent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } 
         catch(Exception e)
         {
            JOptionPane.showMessageDialog(null, e.getMessage());
         }
         try
{
Connection myconnection;
myconnection=DriverManager.getConnection(PATH+PLACE,USERNAME,PASSWORD);
try
{
String q="select * from users";
PreparedStatement mystatement=myconnection.prepareStatement(q);

ResultSet myresult=mystatement.executeQuery();
if(myresult.next())
{
  alogin obj=new alogin();
obj.setVisible(true);  
}
else
{
    adminadd obj=new adminadd();
    obj.setVisible(true);
}

}
catch(Exception e)
{

}
finally
{
myconnection.close();
}

}
catch(Exception e)
{

}
         
    }
     
    
}
